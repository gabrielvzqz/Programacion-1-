package Examen;

import java.util.Scanner;

public class Ejercicio5A {

	public static int main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		double dinero;
		int cien=0;
		int cincuenta=0;
		int veinte=0;
		int diez=0;
		int cinco=0;
		int dos=0;
		int uno=0;

		System.out.println("Cuanto dinero se debe pagar?");
		dinero=sc.nextInt();
		do{
			if(dinero>=100) {
				cien ++;
				dinero-=100;
			}
			if(dinero>=50) {
				cincuenta ++;
				dinero-=50;
			}
			if(dinero>=20) {
				veinte ++;
				dinero-=20;
			}
			if(dinero>=10) {
				diez ++;
				dinero-=10;
			}
			if(dinero>=5) {
				cinco ++;
				dinero-=5;
			}
			if (dinero>=2) {
				dos ++;
				dinero-=2;
			}
			if(dinero>=1) {
				uno ++;
				dinero-=1;
			}
			while(dinero!=0);
			return cien;
			return cincuenta;
			return veinte;
			return diez;
			return cinco;
			return dos;
			return uno;

			System.out.println("Se necesitan: " + cien + " billetes de 100 /n"
					+ cincuenta + " billetes de 50 /n"
					+ veinte + " billetes de 20 /n"
					+ diez + " billetes de 10 /n"
					+ cinco + " billetes de 5 /n"
					+ dos + " monedas de 2 /n"
					+ uno + " monedas de 1, y sobra: " + dinero);
			


}
}
