package Repaso_Bucles;

/*9. Escribir todos los números del 100 al 0 de 7 en 7.*/

public class Ejercicio09 {

	public static void main(String[] args) {
		
		for(int i =100; i>=0; i=i-7) {
			System.out.println(i);
		}

	}

}
