/*1. Leer 5 números y mostrarlos en el mismo orden
introducido.*/
package BoletinArrays;

import java.util.Arrays;

import java.util.Scanner;


public class BoletinArrays1 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		int[] arr= new int [5];
		int numero=0;
		
		for (int i=0; i<arr.length; i++) {
			System.out.println("Introduce un número: ");
			numero=sc.nextInt();
		
			arr[i]=numero;
		}
			System.out.println(Arrays.toString(arr));
			sc.close();

		}

}
