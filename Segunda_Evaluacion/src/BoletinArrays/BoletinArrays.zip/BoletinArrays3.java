/*3. Leer 5 números por teclado y a continuación realizar la
media de los números positivos, la media de los negativos y
contar el número de ceros.*/

package BoletinArrays;

import java.util.Scanner;

public class BoletinArrays3 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		int[] arr = new int[5];
		int numero = 0;
		int positivo = 0;
		int negativo = 0;
		int numnegativos = 0;
		int numpositivos = 0;

		for (int i = 0; i < arr.length; i++) {
			System.out.println("Introduce un número: ");
			arr
		}
			if(numero>=0) {
				positivo+=numero;
				numpositivos++;
				positivo=positivo/numpositivos;
			}
			if(numero<=0) {
				negativo+=numero;
				numnegativos++;
				negativo=negativo/numnegativos;
			}
			System.out.println("La media de los positivos es " + positivo);
			System.out.println("La media de los negativos es " + negativo);
	
		sc.close();

}
}