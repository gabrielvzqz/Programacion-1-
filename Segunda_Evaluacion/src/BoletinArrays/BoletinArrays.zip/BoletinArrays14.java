/*14. Leer dos series de 10 enteros, que estarán ordenados
crecientemente. Copiar (fusionar) las dos tablas en una
tercera, de forma que sigan ordenados.*/

package BoletinArrays;

public class BoletinArrays14 {

}
