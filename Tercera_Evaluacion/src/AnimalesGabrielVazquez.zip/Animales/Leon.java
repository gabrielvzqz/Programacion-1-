package Animales;

public class Leon extends Felino{

	@Override
	public String getSonido() {
		// TODO Auto-generated method stub
		return "MIAU";
	}

	@Override
	public String getAlimento() {
		// TODO Auto-generated method stub
		return "comida";
	}

	@Override
	public String getHabitat() {
		// TODO Auto-generated method stub
		return "Sabana";
	}

	@Override
	public String getNombreCientifico() {
		// TODO Auto-generated method stub
		return "LEON";
	}


}
