package Animales;

public abstract class Felino extends Animal{
	public void hola() {
		System.out.println("hola");
	}
}
