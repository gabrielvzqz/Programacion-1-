package Animales;

public class Lobo extends Canido{

	@Override
	public String getSonido() {
		// TODO Auto-generated method stub
		return "AUUUUUUUUUUUUU";
	}

	@Override
	public String getAlimento() {
		// TODO Auto-generated method stub
		return "comida";
	}

	@Override
	public String getHabitat() {
		// TODO Auto-generated method stub
		return "Bosque";
	}

	@Override
	public String getNombreCientifico() {
		// TODO Auto-generated method stub
		return "Lobo";
	}


}
