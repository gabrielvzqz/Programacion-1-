package Animales;

public abstract class Canido extends Animal{
	public void hola() {
		System.out.println("hola");
	}
}
