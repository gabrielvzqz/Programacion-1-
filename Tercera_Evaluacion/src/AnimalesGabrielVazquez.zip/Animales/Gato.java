package Animales;

public class Gato extends Felino{

	@Override
	public String getSonido() {
		// TODO Auto-generated method stub
		return "MIAU";
	}

	@Override
	public String getAlimento() {
		// TODO Auto-generated method stub
		return "comida";
	}

	@Override
	public String getHabitat() {
		// TODO Auto-generated method stub
		return "casa";
	}

	@Override
	public String getNombreCientifico() {
		// TODO Auto-generated method stub
		return "GATO";
	}
}
